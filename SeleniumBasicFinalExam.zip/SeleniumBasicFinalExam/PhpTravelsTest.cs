﻿using System;
using System.Globalization;
using log4net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using POM.Admin;
using POM.User;
using SeleniumBasicFinalExam.DTO;

namespace SeleniumBasicFinalExam
{
    [TestClass]
    public class PhpTravelsTest
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private BookingDetailsDTO bookingDetailsDTO = new BookingDetailsDTO("Will Travel", "E1232342343", "25", "Bangkok");
        //string uniqueEmail = DateTime.Now.ToString("ddHHmmss") +"cco@test.com"; //TO DELETE
        //Mali ang spelling ng Philippines sa site
        private SupplierDTO supplierDTO = new SupplierDTO("Clarissa", "Ortiaga", "clarissao@magenic.com", "password1", "Phillipines");
        private Browser browser = Browser.Chrome;

        [TestMethod]
        public void TestHard()
        {
            log.Info("Starting Hard test...");
            BasePage basePage = new BasePage();
            string url = @"https://www.phptravels.net/login";

            try
            {
                
                log.Info("Step #1 - Navigate to " + url);
                LoginPage loginPage = basePage.Start(browser, url);

                log.Info("Step #2 - Login with valid username and password.");
                HomePage homePage = loginPage.LoginValid("user@phptravels.com", "demouser");

                log.Info("Step #3 - Navigate to Tours Page.");
                ToursPage toursPage = (ToursPage) homePage.ClickNav(AuthBasePage.NavButton.Tours);

                log.Info("Step #4 - Click random tours.");
                TourInfoPage tourInfoPage = toursPage.ClickFeaturedFlightInfoCard(bookingDetailsDTO);

                log.Info("Step #5 - Verify User is navigated to correct page.");

                log.Info("--Verify title is Tour Name");
                Assert.AreEqual(tourInfoPage.GetTitle(), bookingDetailsDTO.GetTourName());

                log.Info("--Verify Tour Location and Price");
                tourInfoPage.VerifyPriceAndLocation(bookingDetailsDTO);

                log.Info("Step #6 - Click Book Now");
                BookingFormPage bookingFormPage = tourInfoPage.ClickBookNow(bookingDetailsDTO);

                log.Info("Step #7 - Populate all required fields ");
                InvoicePage invoicePage = bookingFormPage.BookFlight(bookingDetailsDTO);

                log.Info("Step #8 - Verify user is navigated to Invoice Page - NOT IMPLEMENTED");
                log.Info("Step #9 - Verify correct booking details - NOT IMPLEMENTED");
                //PAGELOAD ERROR
            }
            catch (AssertFailedException ae)
            {
                log.Error(ae.Message);
                throw ae;
            }
            catch (Exception e)
            {
                log.Fatal(e.StackTrace);
                throw e;
            }
            finally
            {
                basePage.End();
            }
        }

        [TestMethod]
        public void TestMedium()
        {
            log.Info("Starting Medium test...");
            BasePage basePage = new BasePage();
            string url = @"https://www.phptravels.net/admin";

            try
            {
                log.Info("Step #1 - Navigate to " + url);
                AdminLoginPage adminLoginPage = basePage.Start(browser, url);

                log.Info("Step #2 - Login with valid admin username and password.");
                AdminHomePage adminHomePage = adminLoginPage.LoginValid("admin@phptravels.com", "demoadmin");

                log.Info("Step #3 - Navigate to Accounts > Suppliers");
                SuppliersManagementPage suppliersPage = (SuppliersManagementPage) adminHomePage.ClickSidebar(AdminAuthBasePage.SidebarBtn.Accounts_Suppliers);

                log.Info("Step #4 - Verify user is navigated to correct page.");
                Assert.AreEqual("Suppliers Management", suppliersPage.GetPageTitle());

                log.Info("Step #5 - Click add button.");
                AddSupplierPage addSupplierPage = suppliersPage.OpenAddSupplierForm();

                log.Info("Step #6 - Populate fields: First Name, Last Name, Email and Password.");
                log.Info("Step #7 - Set country to: " + supplierDTO.GetCountry());
                log.Info("Step #8 - Click Submit");
                suppliersPage = addSupplierPage.AddSupplier(supplierDTO);

                log.Info("Step #9 - Verify added supplier will be displaued on the Supplier Management table.");
                suppliersPage.VerifySupplierPresent(supplierDTO);
            }
            catch (AssertFailedException ae)
            {
                log.Error(ae.Message);
                throw ae;
            }
            catch (Exception e)
            {
                log.Fatal(e.StackTrace);
                throw e;
            }
            finally
            {
                basePage.End();
            }
        }

        [TestMethod]
        public void TestEasy()
        { 
            log.Info("Starting Easy test...");
            BasePage basePage = new BasePage();
            string url = @"https://www.phptravels.net/login";

            try
            {
                log.Info("Step #1 - Navigate to " + url);
                LoginPage loginPage = basePage.Start(browser, url);

                log.Info("Step #2 - Login with valid username and password.");
                HomePage homePage = loginPage.LoginValid("user@phptravels.com","demouser");

                log.Info("Step #3 - Verify that Hi, <firstname> <lastname> will be displayed.");
                string welcomeText = homePage.GetWelcomeText();
                string expectedWelcomeText = "Hi, Demo User";
                log.Debug("--Expected user welcome text: " + expectedWelcomeText);
                Assert.AreEqual(expectedWelcomeText, welcomeText);

                log.Info("Step #4 - Verify current date will be displayed d MMMM yyyy.");
                string dateInfo = homePage.GetDateInfo();
                DateTime today = DateTime.Today;
                log.Debug("--Expected Date: " + today.ToString("d MMMM yyyy"));
                Assert.AreEqual(today.ToString("d MMMM yyyy"),dateInfo);
            }
            catch (AssertFailedException ae)
            {
                log.Error(ae.Message);
                throw ae;
            }
            catch (Exception e)
            {
                log.Fatal(e.StackTrace);
                throw e;
            }
            finally
            {
                basePage.End();
            }
        }
    }
}
