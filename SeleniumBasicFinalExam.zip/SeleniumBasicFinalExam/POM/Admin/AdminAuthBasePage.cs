﻿using log4net;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using POM.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POM.Admin
{

    public class AdminAuthBasePage : BasePage
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private By SidebarList = By.CssSelector("ul#social-sidebar-menu > li");
        private By SidebarSublist = By.CssSelector("ul > li");

        public AdminAuthBasePage ClickSidebar(SidebarBtn sidebarBtn)
        {
            wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(WaitInMS));
            wait.Until(elem => elem.FindElement(SidebarList));
            log.Debug("sidebar: " + sidebarBtn);
            string[] sidebar = sidebarBtn.ToString().Split('_');
            
            IWebElement sidebarBtnElem = driver.FindElements(SidebarList).Where(elem => elem.Text.Contains(sidebar[0].ToUpper())).FirstOrDefault();
            log.Debug("SideBar: " + sidebarBtnElem.Text);
            log.Debug("TagName: " + sidebarBtnElem.TagName);
            log.Debug("Enabled: " + sidebarBtnElem.Enabled);
            sidebarBtnElem.Click();

            //Sidebar will expand to show Accounts options
            sidebarBtnElem = driver.FindElements(SidebarList).Where(elem => elem.Text.Contains(sidebar[0].ToUpper())).FirstOrDefault();
            IWebElement sidebarSubBtnElem = sidebarBtnElem.FindElements(SidebarSublist).Where(elem => elem.Text.Contains(sidebar[1].ToUpper())).FirstOrDefault();
            log.Debug("Sidebar SubOption: " + sidebarSubBtnElem.Text);
            sidebarSubBtnElem.Click();


            switch (sidebarBtn)
            {
                case SidebarBtn.Accounts_Suppliers:
                    return new SuppliersManagementPage(driver);
                default:
                    Exception sidebarExc = new Exception("No such sidebar.");
                    log.Error(sidebarExc);
                    throw sidebarExc;
            }
        }
         
        public enum SidebarBtn
        {
            Accounts_Suppliers
        }

    }
}