﻿using OpenQA.Selenium;

namespace POM.Admin
{
    public class AdminHomePage : AdminAuthBasePage
    {
        
        public AdminHomePage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public SuppliersManagementPage GotoSuppliersPage()
        {
            return new SuppliersManagementPage(driver);
        }
    }
}