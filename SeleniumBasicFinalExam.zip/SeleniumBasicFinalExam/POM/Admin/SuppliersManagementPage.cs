﻿using log4net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumBasicFinalExam.DTO;
using System;
using System.Collections.Generic;
using System.Linq;

namespace POM.Admin
{
    public class SuppliersManagementPage : AdminAuthBasePage
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private By AddBtnBy = By.CssSelector("form.add_button > button");
        private By TableRowBy = By.CssSelector("table.xcrud-list > tbody > tr");

        public SuppliersManagementPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public AddSupplierPage OpenAddSupplierForm()
        {
            wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(WaitInMS));
            IWebElement addBtn = wait.Until(elem => elem.FindElement(AddBtnBy));
            addBtn.Click();

            return new AddSupplierPage(driver);
        }

        public void VerifySupplierPresent(SupplierDTO supplier)
        {
            //get row with unique email
            IWebElement supplierRow = driver.FindElements(TableRowBy).Where(elem => elem.Text.Contains(supplier.GetEmail())).FirstOrDefault();

            Assert.IsTrue(supplierRow.Displayed);

            IWebElement fNameCell = supplierRow.FindElements(By.CssSelector("td")).Where(elem => elem.Text.Equals(supplier.GetFirstName())).FirstOrDefault();
            IWebElement lNameCell = supplierRow.FindElements(By.CssSelector("td")).Where(elem => elem.Text.Equals(supplier.GetLastName())).FirstOrDefault();

            Assert.IsTrue(fNameCell.Displayed);
            Assert.IsTrue(lNameCell.Displayed);
        }

        internal string GetPageTitle()
        {
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromMilliseconds(WaitInMS);
            return driver.Title;
        }
    }
}