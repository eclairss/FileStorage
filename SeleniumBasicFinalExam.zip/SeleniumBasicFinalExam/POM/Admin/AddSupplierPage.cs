﻿using log4net;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using SeleniumBasicFinalExam.DTO;
using System;

namespace POM.Admin
{
    public class AddSupplierPage : AdminAuthBasePage
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private By FirstNameFldBy = By.CssSelector("input[name=fname]");
        private By LastNameFldBy = By.CssSelector("input[name=lname]");
        private By EmailFldBy = By.CssSelector("input[name=email]");
        private By PasswordFldBy = By.CssSelector("input[name=password]");
        private By CountryFldBy = By.CssSelector("a.select2-choice");
        private By CountrySearchFld = By.CssSelector("div.select2-search > input");
        //private By CountryOptionsBy = By.CssSelector("ul.select2-results > li");
        private By SubmitBtnBy = By.CssSelector("form > div > div > button");

        public AddSupplierPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public SuppliersManagementPage AddSupplier(SupplierDTO supplier)
        {
            //wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(WaitInMS));
            IWebElement firstNameFld = driver.FindElement(FirstNameFldBy);
            IWebElement lastNameFld = driver.FindElement(LastNameFldBy);
            IWebElement emailFld = driver.FindElement(EmailFldBy);
            IWebElement passwordFld = driver.FindElement(PasswordFldBy);
            IWebElement countryFld = driver.FindElement(CountryFldBy);

            firstNameFld.SendKeys(supplier.GetFirstName());
            lastNameFld.SendKeys(supplier.GetLastName());
            emailFld.SendKeys(supplier.GetEmail());
            passwordFld.SendKeys(supplier.GetPassword());
            //countryFld.Click();
            //IWebElement countryList = driver.FindElement(CountryOptionsBy);
            Actions action = new Actions(driver);
            action.Click(countryFld);
            action.MoveToElement(driver.FindElement(CountrySearchFld));
            action.SendKeys(supplier.GetCountry());
            action.SendKeys(Keys.Enter);
            //action.Click(driver.FindElement(CountryOptionsBy));
            action.Perform();

            IWebElement submitBtn = driver.FindElement(SubmitBtnBy);
            ScrollIntoView(submitBtn);
            submitBtn.Click();

            return new SuppliersManagementPage(driver);
        }
    }
}