﻿using log4net;
using OpenQA.Selenium;

namespace POM.User
{
    public class InvoicePage : AuthBasePage
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public InvoicePage(IWebDriver driver)
        {
            this.driver = driver;
        }
    }
}