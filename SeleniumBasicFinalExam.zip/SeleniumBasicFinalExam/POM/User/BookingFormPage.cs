﻿using log4net;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumBasicFinalExam.DTO;
using System;

namespace POM.User
{
    public class BookingFormPage : AuthBasePage
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private By GuestNameBy = By.CssSelector("input[placeholder='Name']");
        private By GuestPassportBy = By.CssSelector("input[placeholder='Passport']");
        private By GuestAgeBy = By.CssSelector("input[placeholder='Age']");
        private By CompleteBookBtnBy = By.CssSelector("button.completebook");

        public BookingFormPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public InvoicePage BookFlight(BookingDetailsDTO bookingDetails)
        {
            wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(4000));
            IWebElement guestNameFld = wait.Until(elem => elem.FindElement(GuestNameBy));
            guestNameFld.SendKeys(bookingDetails.GetPaxName());
            IWebElement guestPassportFld = driver.FindElement(GuestPassportBy);
            guestPassportFld.SendKeys(bookingDetails.GetPassport());
            IWebElement guestAgeFld = driver.FindElement(GuestAgeBy);
            guestAgeFld.SendKeys(bookingDetails.GetAge());
            IWebElement completeBookBtn = driver.FindElement(CompleteBookBtnBy);
            completeBookBtn.Click();
            return new InvoicePage(driver);
        }
    }
}