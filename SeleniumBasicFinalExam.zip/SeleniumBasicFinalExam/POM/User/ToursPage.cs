﻿using log4net;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumBasicFinalExam.DTO;
using System;
using System.Linq;

namespace POM.User
{
    public class ToursPage : AuthBasePage
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private By DestinationBy = By.CssSelector("input.select2-input");
        private By TourTypeBy = By.CssSelector("select#tourtype");
        private By DateBy = By.CssSelector("input#DateTours");
        private By PaxSizeBy = By.CssSelector("input[name='adults']");
        private By SearchBtnBy = By.CssSelector("button[text()='Search']");
        private By FtdToursHeaderBy = By.CssSelector("div.section-title > h2");
        private By TourInfoCardBy = By.CssSelector("figure.featured-image-grid-item");
        private By TourNameBy = By.CssSelector("figcaption > h5.RTL");
        private By TourLocationBy = By.CssSelector("p.location");
        private By TourPriceBy = By.CssSelector("figcaption > div > div > span > span");

        public ToursPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public TourInfoPage ClickFeaturedFlightInfoCard(BookingDetailsDTO bookingDetails)
        {
            wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(WaitInMS));
            IWebElement ftdToursHeader = wait.Until(elem => elem.FindElement(FtdToursHeaderBy));
            log.Debug("Section Title: " + ftdToursHeader.Text);

            ScrollIntoView(ftdToursHeader);

            driver.Manage().Timeouts().PageLoad = TimeSpan.FromMilliseconds(WaitInMS);
            IWebElement tourInfoCard = driver.FindElements(TourInfoCardBy).Where(elem => elem.Text.Contains(bookingDetails.GetLocation())).FirstOrDefault();
            log.Debug("tourInfoCard: " + tourInfoCard.Text);
            IWebElement tourName = tourInfoCard.FindElement(TourNameBy);
            //IWebElement tourLocation = tourInfoCard.FindElement(TourLocationBy);
            IWebElement tourPrice = tourInfoCard.FindElement(TourPriceBy);
            bookingDetails.SetTourName(tourName.Text);
            //bookingDetails.SetLocation(tourLocation.Text);
            bookingDetails.SetTourPrice(tourPrice.Text);
            //Actions actions = new Actions(driver);
            //actions.DoubleClick(tourInfoCard).Perform();
            tourInfoCard.Click();

            return new TourInfoPage(driver);
        }

        //Untested
        public void SearchFlight(string destination, TourType tourType, string dateTo, string paxSize)
        {
            //wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(WaitInMS));
            IWebElement destinationField = wait.Until(elem => elem.FindElement(DestinationBy));
            //IWebElement destinationField = driver.FindElement(DestinationBy);
            destinationField.SendKeys(destination);
            SelectElement tourTypeDd = new SelectElement(driver.FindElement(TourTypeBy));
            tourTypeDd.SelectByText(tourType.ToString());
            IWebElement dateField = driver.FindElement(DateBy);
            dateField.SendKeys(dateTo);
            IWebElement paxSizeFld = driver.FindElement(PaxSizeBy);
            paxSizeFld.SendKeys(paxSize);
            IWebElement searchBtn = driver.FindElement(SearchBtnBy);
        }
    }

    public enum TourType
    {
        Private,
        Couples
    }
}