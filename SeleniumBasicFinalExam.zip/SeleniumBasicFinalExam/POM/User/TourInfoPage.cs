﻿using System;
using System.Linq;
using log4net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using POM.User;
using SeleniumBasicFinalExam;
using SeleniumBasicFinalExam.DTO;

namespace POM.User
{
    public class TourInfoPage : AuthBasePage
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private By PaxSizeBy = By.CssSelector("select#selectedAdults");
        private By BookNowBtnBy = By.CssSelector("form[role='search'] > button");
        private By TourPriceInfoBy = By.CssSelector("div.adult-Price > h6");
        private By LocationInfoBy = By.CssSelector("p.location");
        private By TourNameBy = By.CssSelector("h2#detail-content-sticky-nav-00");
        
        public TourInfoPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public BookingFormPage ClickBookNow(BookingDetailsDTO bookingDetails)
        {
            wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(WaitInMS));
            IWebElement bookNowBtn = wait.Until(elem => elem.FindElement(BookNowBtnBy));
            SelectElement paxSizeDd = new SelectElement(driver.FindElement(PaxSizeBy));
            paxSizeDd.SelectByText("1");

            bookNowBtn.Click();

            return new BookingFormPage(driver);
        }

        public string GetTitle()
        {
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromMilliseconds(WaitInMS);
            log.Debug("Tour Info Page Title: " + driver.Title);
            return driver.Title;
        }

        public void VerifyPriceAndLocation(BookingDetailsDTO bookingDetailsDTO)
        {
            wait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(WaitInMS));
            IWebElement tourPriceInfo = wait.Until(elem => elem.FindElement(TourPriceInfoBy));
            IWebElement locationInfo = driver.FindElement(LocationInfoBy);
            IWebElement tourNameInfo = driver.FindElement(TourNameBy);
            string location = locationInfo.Text;
            //location = location.Substring("place ".Length - 1, location.Length - (",… SHOW ON MAP".Length + "place".Length));

            log.Debug("Location: " + location);
            log.Debug("TourNameInfo: " + tourNameInfo.Text);
            log.Debug("Price: " + tourPriceInfo.Text);

            Assert.IsTrue(location.Contains(bookingDetailsDTO.GetLocation()));
            Assert.IsTrue(tourPriceInfo.Text.Contains(bookingDetailsDTO.GetTourPrice()));
            log.Info("Assert Result: Tour location and price information is correct.");
        }
    }
}