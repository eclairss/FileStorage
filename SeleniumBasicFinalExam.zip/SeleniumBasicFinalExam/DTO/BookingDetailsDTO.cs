﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumBasicFinalExam.DTO
{
    public class BookingDetailsDTO
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private string PaxName;
        private string Passport;
        private string Age;
        private string TourName;
        private string TourPrice;
        private string Location;

        public BookingDetailsDTO(string PaxName, string Passport, string Age, string Location)
        {
            this.PaxName = PaxName;
            this.Passport = Passport;
            this.Age = Age;
            this.Location = Location;
        }

        public string GetTourPrice()
        {
            return TourPrice;
        }

        public void SetTourPrice(string tourPrice)
        {
            this.TourPrice = tourPrice;
            log.Debug("Tour Price: " + TourPrice);
        }

        public string GetTourName()
        {
            log.Debug("Tour Name: " + TourName);
            return TourName;
        }

        public void SetTourName(string tourName)
        {
            this.TourName = tourName;
            log.Debug("Tour Name: " + TourName);
        }

        public void SetLocation(string location)
        {
            this.Location = location;
            log.Debug("Tour Location: " + Location);
        }

        public string GetPaxName()
        {
            log.Debug("Pax PaxName: " + PaxName);
            return this.PaxName;
        }

        public void SetPaxName(string paxName)
        {
            this.PaxName = paxName;
        }

        public string GetPassport()
        {
            log.Debug("Pax Passport: " + Passport);
            return this.Passport;
        }

        public string GetAge()
        {
            log.Debug("Pax Age: " + Age);
            return Age;
        }

        public string GetLocation()
        {
            return this.Location;
        }
    }
}
